# Componentes locais

- PDF.js / pdfjs-dist 5.4.296 — Mozilla e colaboradores. Licença Apache-2.0. https://github.com/mozilla/pdf.js . Licença incluída em vendor/pdf/LICENSE; fontes/cmaps incluem seus próprios avisos.
- Tesseract.js 6.0.1 — naptha e colaboradores. Licença Apache-2.0. https://github.com/naptha/tesseract.js . Licença incluída em vendor/ocr/LICENSE.md.
- Tesseract.js-core 6.1.2 — colaboradores do projeto Tesseract. Licença Apache-2.0. https://github.com/naptha/tesseract.js-core . Licença incluída em vendor/ocr/core/LICENSE.
- @tesseract.js-data/por 1.0.0 — dados de português do projeto Tesseract/tessdata. Licença Apache-2.0. https://github.com/tesseract-ocr/tessdata_best . Texto Apache-2.0 disponível nos arquivos LICENSE acima.

Pacotes obtidos do registro oficial npm, com integridade SHA-512 conferida. O pacote não carrega código desses sites durante o uso. Não foram incorporados os motores, dados nem regras CATMAS/RP da extensão de exemplo: ela serviu como referência do padrão de integração visual e de formulários SEI.
