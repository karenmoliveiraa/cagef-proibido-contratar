# CAGEF ↔ SEI — versão 0.4

## Instalar / atualizar no Chrome

Extraia o ZIP em uma pasta permanente. Em chrome://extensions, ative o Modo do desenvolvedor e use Carregar sem compactação na pasta que contém manifest.json. Desative a versão antiga para não manter duas instalações. Se estiver substituindo os arquivos da mesma pasta, clique em Recarregar no cartão da extensão. Atualize a aba SEI depois da atualização. A versão solicita acesso aos dois domínios oficiais do SEI-MG e do CAGEF para executar as etapas autorizadas. Não solicita acesso permanente aos demais sites.

O botão CAGEF / SEI aparece na barra de ações de um processo aberto. O painel lateral foi mantido, agora com três etapas. Chrome é o alvo desta versão. Firefox continua sem pacote/homologação próprios.

## 1. Dados e fontes

Ao abrir um processo pela primeira vez, a extensão abre as pastas da árvore e inventaria seus documentos. A leitura ocorre em sequência, de todas as páginas dos PDFs acessíveis, de documentos HTML e de imagens. PDFs sem camada textual usam OCR local em português. Os motores PDF.js e Tesseract já estão incluídos no pacote; não há envio do processo para IA ou OCR externos.

O painel mostra quantos documentos foram processados e a situação de cada um. Documento cancelado é indicado e não usado como fundamento. Formatos não suportados, erros de acesso, PDFs protegidos, arquivo acima de 24 MB ou OCR de baixa confiança ficam pendentes. Esses casos bloqueiam a automação: importe a versão legível correspondente em PDF/TXT no item pendente e revise. A importação recompõe as sugestões, podendo substituir edições anteriores. Não há promessa de interpretar qualquer formato ou toda formulação judicial.

O preenchimento usa regras locais para localizar identidades completas próximas a sanções, prazos e termos iniciais. São sugestões, não uma conclusão jurídica automática. Cada pessoa tem trechos/fontes e deve ser confirmada como sujeita à sanção. Pessoas apenas citadas, advogados, signatários e réus com situações diferentes precisam ser excluídos quando indevidamente sugeridos. Não há acesso a dados ocultos, a processos relacionados ou a documentos para os quais o usuário não tenha permissão.

Se houver mais de um prazo ou início próximo ao mesmo CPF/CNPJ, o campo pode ficar vazio e as alternativas são exibidas para escolha. A extensão não presume que data da sentença é início da contagem. Não calcula automaticamente a data final da pena. CPF/CNPJ numérico deve passar pela validação de dígitos.

São preenchidos também os dados de solicitação e do documento que comunica a condenação, todos editáveis. Confira-os no texto original. A existência de anexos CAGEF, respostas anteriores ou retificações gera aviso e exige conferência antes de avançar. Revise todos os documentos, confirme cada pessoa e marque a revisão geral.

## 2. Anotações e PDF

Para cada condenado, confira e edite o texto e marque sua autorização. Acessar CAGEF e executar esta anotação abre ou seleciona uma aba do CAGEF. Faça login normalmente e selecione a unidade quando solicitado. A extensão não guarda nem preenche senhas.

O agente começa pela consulta de anotações. Se achar registro para o mesmo processo judicial, reutiliza a consulta, sem criar outra anotação. O campo de origem da evidência distingue Unidade Cadastradora de CAFIMP. Se houver mais de uma correspondência, divergência de identidade, consulta inconclusiva ou formulário diferente, o agente interrompe e informa o motivo.

Quando a consulta confirmar ausência e o formulário for reconhecido, a extensão prepara os dados e aciona a gravação uma única vez, conforme a autorização concedida. Para fornecedor já cadastrado sem anotação desse processo, tenta usar Nova Anotação; para não cadastrado, usa o cadastro correspondente. Uma indicação CAFIMP no cadastro exige conferência, para evitar registro manual desnecessário. Falta de confirmação de sucesso não é tratada como salvamento; confira o CAGEF antes de repetir.

Depois de salvar ou localizar o registro existente, abra a consulta com CPF/CNPJ e toda a anotação visíveis. Clique no ícone da extensão na barra do navegador dessa aba. Esse clique concede a permissão temporária de captura. A extensão verifica que identidade e anotação estão na área visível antes de capturar. Se necessário, ajuste zoom/posicionamento. O PDF gerado contém a imagem da tela; não é um texto que simule registro salvo.

Volte ao painel SEI. O PDF pode ser baixado para revisão e incluído pelo botão Inserir este PDF no processo SEI. Também é possível importar um PDF da consulta já existente, preparado manualmente. Marque a conferência específica do PDF antes da inclusão.

O envio usa documento externo de tipo Anexo, nome na árvore CAGEF - NOME DO CONDENADO (que compõe Anexo CAGEF - NOME), Nato-digital, nível Restrito e hipótese exata Dados Pessoais (LGPD) (Lei 13.709/18). Não escolhe a hipótese de consentimento e não muda para Público como alternativa. A aplicação aguarda o arquivo aparecer na lista antes de salvar. Confirma o novo documento na árvore e preenche seu número SEI na ficha do condenado. Você também pode indicar o número de um anexo existente após conferi-lo.

Cancelar uma operação impede os próximos comandos, mas não desfaz gravação/upload já realizado. Sempre confira a árvore e o CAGEF antes de tentar novamente.

## 3. Memorando

Depois de registrar todos os números SEI dos anexos, avance para o memorando. O painel muda para mostrar as variáveis pré-preenchidas, editáveis, e a prévia integral. O modelo segue o Memorando 245: Ana Luiza Camargo Hirle, Subsecretária de Compras Públicas; vocativo Prezada Subsecretária; referência ao processo; solicitação e documento de condenação; identificação do(s) condenado(s); origem real da anotação e número(s) SEI dos anexos; fecho e signatária Samira Marx Pinheiro.

CPF aparece mascarado por padrão, conforme o modelo, com opção de ajustar. A redação usa singular ou plural e distingue registro manual de recuperação CAFIMP. Alterar as variáveis regenera a prévia e exige nova autorização. O número do processo na referência deve coincidir com o processo aberto.

Há download TXT da minuta. Para criar no SEI, confira a redação e marque a autorização explícita. A extensão cria memorando interno Restrito / Dados Pessoais, preenche somente áreas vazias reconhecidas do modelo do editor e salva. Se o editor/modelo for diferente ou já tiver conteúdo, interrompe para não sobrescrever. O texto é conferido depois no documento salvo antes de informar conclusão. A assinatura não é feita pela extensão. Número e data do memorando são gerados pelo SEI.

## Privacidade e armazenamento

Sem senha, chave de IA, telemetria ou serviço próprio. Requisições de processo/anotação são feitas somente aos sistemas corporativos autorizados. Os motores de PDF/OCR são locais, com versões e integridades registradas em vendor/versions.json.

Rascunhos e estados de operação ficam em chrome.storage.session. Os textos dos documentos, PDFs e capturas ficam no IndexedDB da extensão no navegador até apagar os dados do processo. Fechar o navegador não apaga esse IndexedDB. Use Apagar dados locais deste processo ao concluir; downloads e área de transferência permanecem sob sua gestão. Não edite o mesmo caso simultaneamente em vários painéis.

## Validação e limites conhecidos

Inspeção autenticada e somente de leitura em 27/10/2026: árvore SEI, visualizador de anexo, cadastro externo e hipótese de restrição; pesquisa e visualização de anotação existente no CAGEF. Não foi salva nova anotação, não foi enviado arquivo e não foi criado memorando nos sistemas reais nesta atualização.

Testes locais: HTML e PDF com preenchimento do painel; OCR em português (95% de confiança na imagem sintética de teste); passagem às etapas de anotações e de memorando; captura convertida em PDF, reaberta, validada e renderizada; formulário externo simulado com envio de arquivo, classificação Restrito/Dados Pessoais exata e um único acionamento de Salvar; testes de extração, conflitos e sequência/autorizações do serviço.

Esses testes não substituem homologação da extensão instalada no Chrome com os sistemas reais. A gravação CAGEF e o editor do memorando podem exigir ajustes se a interface/eventos forem diferentes dos mapeados. A extensão deve interromper nesses casos e apresentar erro, sem afirmar conclusão.

O processo 1080.01.0091399/2026-20 permanece referência concluída. O processo 1630.01.0001874/2026-37 também já contém Memorando 251, anexos CAGEF e uma retificação; não deve receber documentos/anotações repetidos apenas para testar a extensão.

Para testes unitários: node tests.mjs; node background-tests.mjs; node v04-tests.mjs; node worker-tests.mjs. Não é necessário instalar Node para usar a extensão no Chrome.
