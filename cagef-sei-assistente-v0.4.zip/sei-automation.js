(() => {
 const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
 const visible=e=>e&&e.getClientRects().length&&!e.disabled;
 const send=(action,extra={})=>chrome.runtime.sendMessage({type:'CAGEF_AGENT',action,...extra});
 const change=(e,value)=>{if(!e)throw Error('Campo necessário não encontrado.');if(e.maxLength>0&&value.length>e.maxLength)throw Error('Valor maior que o limite do campo.');e.value=value;e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));};
 const oneButton=name=>[...document.querySelectorAll('button,input[type=submit],input[type=button],a')].filter(e=>visible(e)&&norm(e.value||e.textContent)===norm(name))[0];
 const claim=async(job,to)=>(await send('CLAIM',{from:job.stage,to})).claimed;
 let busy=false,notice,lastWait=Date.now();
 function show(text){if(!notice){notice=document.createElement('div');notice.style.cssText='position:fixed;bottom:14px;right:14px;background:white;color:#183142;border:2px solid #176b75;border-radius:8px;padding:14px;max-width:440px;z-index:2147483647;font:14px Arial';document.body.append(notice);}notice.replaceChildren(document.createTextNode(text));const b=document.createElement('button');b.textContent='Cancelar automação';b.onclick=()=>send('FAIL',{message:'Cancelado pelo operador. Confira o SEI antes de repetir.'});notice.append(document.createElement('br'),b);}
 const fail=async text=>{await send('FAIL',{message:text});show(text);};
 function same(job){const local=document.getElementById('hdnIdProcedimento')?.value||new URL(location.href).searchParams.get('id_procedimento');if(local)return local===job.procedureId;let title='';try{title=window.top.document.title;}catch{}return title.includes(job.process);}
 function restricted(){const restrict=document.getElementById('optRestrito'),hyp=document.getElementById('selHipoteseLegal');return restrict?.checked&&norm(hyp?.selectedOptions[0]?.textContent)==='dados pessoais (lgpd) (lei 13.709/18)';}
 async function tick(){if(busy)return;busy=true;try{
  const {job,error}=await send('GET');if(error||!job||job.kind==='cagef')return;
  if(job.stage==='type'){
   const heading=norm(document.querySelector('h1')?.textContent);
   if(!/gerar documento/.test(heading))return;
   const target=job.kind==='external'?'externo':'memorando';const links=[...document.querySelectorAll('a')].filter(e=>visible(e)&&norm(e.textContent)===target);
   if(links.length===1&&same(job)&&await claim(job,job.kind==='external'?'form':'metadata')){show(`Selecionando ${target} para o processo ${job.process}.`);links[0].click();}
  }else if(job.stage==='form'){
   if(norm(document.querySelector('h1')?.textContent)!=='registrar documento externo')return;if(!same(job))return fail('Processo não confirmado no formulário externo.');
   const type=document.getElementById('selSerie'),date=document.getElementById('txtDataElaboracao'),name=document.getElementById('txtNomeArvore'),nato=document.getElementById('optNato'),restrict=document.getElementById('optRestrito'),hyp=document.getElementById('selHipoteseLegal'),file=document.getElementById('filArquivo');
   if(!type||!date||!name||!nato||!restrict||!hyp||!file)return fail('Formulário externo diferente do mapeado. Nenhum documento foi salvo.');
   const options=[...type.options].filter(o=>norm(o.textContent)==='anexo');if(options.length!==1)return fail('Tipo Anexo não encontrado.');
   if(type.value!==options[0].value){show('Selecionando Anexo e aguardando recarga do formulário…');change(type,options[0].value);return;}
   if(!restrict.checked){restrict.click();return;}
   const legal=[...hyp.options].filter(o=>norm(o.textContent)==='dados pessoais (lgpd) (lei 13.709/18)');if(legal.length!==1){show('Aguardando hipótese legal Dados Pessoais (LGPD)…');if(Date.now()-lastWait>45000)return fail('Hipótese de Dados Pessoais não foi carregada. Confira manualmente.');return;}
   change(hyp,legal[0].value);nato.click();
   const formatted=new Intl.DateTimeFormat('pt-BR',{timeZone:'America/Sao_Paulo'}).format(new Date());change(date,date.type==='date'?formatted.split('/').reverse().join('-'):formatted);
   // Tipo Anexo + nome CAGEF gera a árvore ANEXO CAGEF - NOME.
   change(name,job.name.replace(/^ANEXO\s+/i,''));
   if(!restricted()||!nato.checked)return fail('Classificação não confirmada; inclusão interrompida.');
   const existing=document.querySelector('#tblAnexos tbody tr');if(file.files.length||existing&&/\.pdf/i.test(existing.textContent))return fail('Já há arquivo neste formulário. Confira antes de repetir.');
   const stored=await send('FILE');if(!stored?.base64)return fail('PDF não disponível no armazenamento local.');
   const bytes=Uint8Array.from(atob(stored.base64),c=>c.charCodeAt(0)),transfer=new DataTransfer();transfer.items.add(new File([bytes],stored.name,{type:'application/pdf'}));
   if(await claim(job,'uploading')){file.files=transfer.files;file.dispatchEvent(new Event('change',{bubbles:true}));show('Enviando PDF. Aguardando confirmação na lista de anexos…');}
  }else if(job.stage==='uploading'){
   if(!same(job)||norm(document.querySelector('h1')?.textContent)!=='registrar documento externo')return;
   const stored=await send('FILE');const rows=[...document.querySelectorAll('#tblAnexos tr')].filter(r=>r.textContent.includes(stored?.name||'\0'));
   if(rows.length!==1||/enviando|aguarde|erro|falha/i.test(rows[0].textContent))return;
   if(!restricted()||!document.getElementById('optNato')?.checked)return fail('Arquivo enviado, mas classificação mudou. Nenhum Salvar foi acionado.');
   const save=oneButton('Salvar');if(!save)return fail('Botão Salvar não encontrado.');
   if(await claim(job,'submitted')){save.click();show('Salvar acionado. A confirmação será feita pela presença do novo documento na árvore.');}
  }else if(job.stage==='metadata'){
   if(!document.getElementById('txtDescricao')||!document.getElementById('optNenhum'))return;if(!same(job))return fail('Processo não confirmado no cadastro do memorando.');
   const restrict=document.getElementById('optRestrito'),hyp=document.getElementById('selHipoteseLegal');if(!restrict||!hyp)return fail('Cadastro de memorando sem classificação esperada.');
   if(!restrict.checked){restrict.click();return;}
   const legal=[...hyp.options].filter(o=>norm(o.textContent)==='dados pessoais (lgpd) (lei 13.709/18)');if(legal.length!==1)return;
   change(hyp,legal[0].value);change(document.getElementById('txtDescricao'),'Anotação CAGEF - Proibição de contratar');document.getElementById('optNenhum').click();
   if(!restricted())return fail('Acesso restrito não confirmado.');const save=oneButton('Salvar');if(!save)return fail('Salvar não encontrado.');
   if(await claim(job,'editor')){show('Criando rascunho do memorando. Aguardando editor…');save.click();}
  }else if(job.stage==='editor'){
   if(!document.querySelector('[id^=cke_],.cke'))return;
   const result=await send('FILL_MEMO');if(result?.error)return fail(result.error);if(!result?.filled)return;
   const save=oneButton('Salvar');if(!save)return fail('Minuta preenchida. Salve manualmente no editor e confira antes de assinar.');
   if(await claim(job,'verify')){save.click();show('Texto preenchido e Salvar acionado. Revise no SEI. A extensão não assina o memorando.');}
  }
 }catch(e){await fail(`Automação interrompida: ${e.message}. Confira se já houve criação antes de repetir.`);}finally{busy=false;}}
 setInterval(tick,1200);tick();
})();
