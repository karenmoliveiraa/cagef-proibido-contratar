const isSei = raw => {try { const u=new URL(raw);return u.protocol==='https:'&&['sei.mg.gov.br','www.sei.mg.gov.br'].includes(u.hostname)&&u.pathname.startsWith('/sei/'); }catch{return false;}};
async function contextFor(tab, process='') {
  const token=crypto.randomUUID();
  const last=(await chrome.storage.session.get('lastProcess')).lastProcess;
  const key=process?`case:${process}`:last||`tab:${tab.id}`;
  const context={target:{id:tab.id,url:tab.url,windowId:tab.windowId},process,draftKey:key};
  await chrome.storage.session.set({[`context:${token}`]:context,...(process?{lastProcess:key}:{})});
  return {url:chrome.runtime.getURL(`app.html?context=${token}`)};
}
chrome.runtime.onMessage.addListener((message,sender,respond)=>{
  if(message?.type==='CAGEF_OPEN_CONTEXT'&&sender.tab&&sender.frameId===0&&isSei(sender.url)) {
    const process=/^\d{4}\.\d{2}\.\d{7}\/\d{4}-\d{2}$/.test(message.process||'')?message.process:'';
    contextFor(sender.tab,process).then(respond,e=>respond({error:e.message}));return true;
  }
  if(message?.type==='CAGEF_GET_CONTEXT'&&sender.url?.split('?')[0]===chrome.runtime.getURL('app.html')) {
    chrome.storage.session.get(`context:${message.token}`).then(r=>respond(r[`context:${message.token}`]||null));return true;
  }
});
chrome.action.onClicked.addListener(async tab=>{
  if(!tab.id||!/^https?:/.test(tab.url||''))return;
  if(typeof isCagef==='function'&&isCagef(tab.url))return;
  if(isSei(tab.url)){
    try{await chrome.tabs.sendMessage(tab.id,{type:'CAGEF_TOGGLE_PANEL'},{frameId:0});return;}
    catch{await chrome.scripting.executeScript({target:{tabId:tab.id},files:['sei-panel.js']});await chrome.tabs.sendMessage(tab.id,{type:'CAGEF_TOGGLE_PANEL'},{frameId:0});return;}
  }
  const context=await contextFor(tab);await chrome.tabs.create({url:context.url});
});
importScripts('worker-v04.js');
