(() => {
  'use strict';
  if(window.top!==window||document.getElementById('cagef-sei-host'))return;
  const host=document.createElement('div');host.id='cagef-sei-host';document.documentElement.append(host);
  const root=host.attachShadow({mode:'open'});
  root.innerHTML=`<style>
    :host{all:initial}*{box-sizing:border-box}#panel{position:fixed;right:16px;top:16px;bottom:16px;width:min(580px,calc(100vw - 24px));z-index:2147483646;background:#edf2f5;color:#183142;border:1px solid #b9cdd3;border-radius:14px;box-shadow:0 16px 52px #0005;overflow:hidden;display:flex;flex-direction:column;font:14px/1.45 Arial,sans-serif}#panel[hidden]{display:none}.head{display:flex;align-items:center;padding:14px 16px;background:#153f4a;color:white;gap:12px}.head strong{flex:1;font-size:16px}.head button{color:white;background:transparent;border:0;font-size:22px;cursor:pointer}.context{padding:10px 16px;background:white;border-bottom:1px solid #cbd9df;font-size:12px}.context p{margin:3px 0}iframe{border:0;width:100%;flex:1;min-height:0;background:#edf2f5}.foot{padding:9px 14px;background:white;border-top:1px solid #cbd9df;font-size:11px}#loading{padding:20px}button:focus-visible{outline:3px solid #60b9ca;outline-offset:2px}
  </style><aside id="panel" aria-label="Assistente CAGEF — Proibição de contratar" hidden><div class="head"><strong>CAGEF · Proibição de contratar</strong><button id="close" type="button" aria-label="Fechar painel CAGEF">×</button></div><div class="context"><p id="process"></p><p>Confira os dados e as minutas antes de executar cada etapa.</p></div><p id="loading" role="status"></p><div class="foot">Processamento local. Nenhum registro é salvo nos sistemas ao abrir este painel.</div></aside>`;
  const panel=root.getElementById('panel'),processLabel=root.getElementById('process'),loading=root.getElementById('loading');
  let button=null,frame=null,currentProcess='',opening=false,lastFocus=null;
  const observed=new WeakSet();
  function walk(callback,doc=document,seen=new Set()){
    if(!doc?.documentElement||seen.has(doc))return;seen.add(doc);callback(doc);
    for(const el of doc.querySelectorAll('iframe,frame')){try{if(el.contentDocument)walk(callback,el.contentDocument,seen);}catch{/* outro domínio */}}
  }
  function processNumber(){
    let found='';
    walk(doc=>{if(found)return;const match=(doc.title||'').match(/\b\d{4}\.\d{2}\.\d{7}\/\d{4}-\d{2}\b/);if(match)found=match[0];
      if(!found)for(const a of doc.querySelectorAll('#topmenu a')){const text=a.textContent.trim();if(/^\d{4}\.\d{2}\.\d{7}\/\d{4}-\d{2}$/.test(text)){found=text;break;}}});return found;
  }
  function close(){panel.hidden=true;button?.setAttribute('aria-expanded','false');lastFocus?.focus();}
  async function open(){
    if(opening)return;const process=processNumber();if(!process)return;
    lastFocus=button;panel.hidden=false;button?.setAttribute('aria-expanded','true');root.getElementById('close').focus();
    if(frame&&process===currentProcess)return;
    opening=true;loading.hidden=false;loading.textContent='Carregando assistente deste processo…';
    try{
      const context=await chrome.runtime.sendMessage({type:'CAGEF_OPEN_CONTEXT',process});
      if(!context?.url||context.error)throw Error(context?.error||'Não foi possível vincular o processo.');
      if(processNumber()!==process){close();return;}
      frame?.remove();frame=document.createElement('iframe');frame.title='Conferência de dados e minutas CAGEF';frame.allow='clipboard-write';frame.src=context.url+'&embedded=1';
      frame.addEventListener('load',()=>{loading.hidden=true;});panel.insertBefore(frame,root.querySelector('.foot'));
      currentProcess=process;processLabel.textContent=`Processo ${process}`;
    }catch(e){loading.textContent=e.message;}finally{opening=false;}
  }
  function toggle(){if(panel.hidden)open();else close();}
  function sync(){
    let toolbar=null;const process=processNumber();
    walk(doc=>{
      if(!observed.has(doc)){new MutationObserver(schedule).observe(doc.documentElement,{childList:true,subtree:true});doc.addEventListener('load',schedule,true);observed.add(doc);}
      if(toolbar)return;for(const candidate of doc.querySelectorAll('#divArvoreAcoes'))if(candidate.getClientRects().length){toolbar=candidate;break;}
    });
    if(currentProcess&&process!==currentProcess){close();frame?.remove();frame=null;currentProcess='';}
    if(!toolbar||!process){button?.remove();button=null;return;}
    if(button?.isConnected&&button.parentElement===toolbar)return;
    button?.remove();const doc=toolbar.ownerDocument;
    if(!doc.getElementById('cagef-sei-toolbar-style')){const style=doc.createElement('style');style.id='cagef-sei-toolbar-style';style.textContent=`#cagef-sei-toolbar-button{display:inline-flex!important;flex-direction:column;align-items:center;justify-content:center;vertical-align:top;box-sizing:border-box;width:44px;height:40px;margin:3px 5px;padding:0;border:0;border-radius:7px;background:#176b75;color:white;font:800 10px/13px Arial,sans-serif;cursor:pointer;letter-spacing:0}#cagef-sei-toolbar-button:hover{background:#124d55}#cagef-sei-toolbar-button:focus-visible{outline:3px solid #60b9ca;outline-offset:2px}`;doc.head.append(style);}
    button=doc.createElement('button');button.id='cagef-sei-toolbar-button';button.type='button';button.title='CAGEF — Proibição de contratar';button.setAttribute('aria-label','Abrir assistente CAGEF — Proibição de contratar');button.setAttribute('aria-expanded',String(!panel.hidden));
    for(const text of ['CAGEF','SEI']){const span=doc.createElement('span');span.textContent=text;button.append(span);}
    button.addEventListener('click',event=>{event.preventDefault();event.stopPropagation();toggle();});toolbar.append(button);
  }
  let scheduled=false;function schedule(){if(scheduled)return;scheduled=true;setTimeout(()=>{scheduled=false;sync();},180);}
  root.getElementById('close').onclick=close;
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!panel.hidden)close();});
  chrome.runtime.onMessage.addListener(message=>{if(message?.type==='CAGEF_TOGGLE_PANEL'){sync();toggle();}});
  sync();setInterval(sync,2500);
})();
