export function digits(s) { return s.replace(/\D/g, ''); }
export function validId(value, type) {
  const d = digits(value);
  if (/^(.)\1+$/.test(d)) return false;
  if (type === 'CPF') {
    if (!/^\d{11}$/.test(d)) return false;
    for (let n=9;n<=10;n++) {
      let sum=0; for(let i=0;i<n;i++) sum+=Number(d[i])*(n+1-i);
      if (Number(d[n]) !== (sum*10%11)%10) return false;
    }
    return true;
  }
  // CNPJ numérico; formatos diferentes exigem atualização do validador.
  if (!/^\d{14}$/.test(d)) return false;
  for (let n=12;n<=13;n++) {
    let sum=0, weight=n-7;
    for(let i=0;i<n;i++){sum+=Number(d[i])*weight;weight=weight===2?9:weight-1;}
    const r=sum%11; if(Number(d[n])!==(r<2?0:11-r))return false;
  }
  return true;
}
export function annotation(c, p) {
  return `CONFORME OFÍCIO ${c.oficio}, ORIUNDO DE ${c.orgao}, QUE REMETE À SENTENÇA PROFERIDA NOS AUTOS DO PROCESSO Nº ${c.judicial}, FOI IMPOSTA A ${p.nome}, ${p.tipo} ${p.doc}, A SEGUINTE SANÇÃO: ${p.sancao}. PRAZO: ${p.prazo}. TERMO INICIAL: ${p.inicio}. FUNDAMENTO DO TERMO INICIAL: ${p.fundamento}.`;
}
export function memorandum(c, persons) {
  const recovered=persons.every(p=>p.origem==='CAFIMP');
  const manual=persons.every(p=>p.origem==='Manual');
  const how=recovered?'a partir de recuperação de informações por meio de integração com o CAFIMP':manual?'por meio de registro manual no CAGEF':'por registro manual ou recuperação por integração com o CAFIMP, conforme indicado para cada réu/condenado';
  return `Para: Ana Luiza Camargo Hirle\nSubsecretária de Compras Públicas\n\nReferência: Processo nº ${c.processo}\n\nPrezada Senhora,\n\nEm atenção ao ${c.tipoOrigem||'Memorando'} ${c.memorando} (Documento SEI ${c.memoSei}), que solicita providências para atendimento à sentença judicial de proibição de contratar com o Poder Público, constante no Ofício ${c.oficio} (Documento SEI ${c.oficioSei}), presto os seguintes esclarecimentos.\n\nAs informações de fornecedores impedidos são registradas no Cadastro Geral de Fornecedores - CAGEF por meio de anotação no cadastro do respectivo fornecedor a partir das notícias recebidas acerca do impedimento, ou a partir de recuperação de informações por meio de integração com o Cadastro de Fornecedores Impedidos de Licitar e Contratar com a Administração Pública Estadual – CAFIMP, gerido pela Controladoria-Geral do Estado, na hipótese da inscrição no CAFIMP já ter sido efetuada.\n\nInformo, ainda, que foi realizada a anotação no sistema do CAGEF, em relação aos réus/condenados ${persons.map(p=>`${p.nome}, ${p.tipo} ${p.doc}${manual||recovered?'':` (${p.origem})`}`).join('; ')}, ${how}, conforme anexos (Documentos SEI ${persons.map(p=>p.anexoSei||'[PENDENTE]').join(' e ')}).\n\nAtenciosamente,\n\nSamira Marx Pinheiro\nDiretora Central de Cadastros`;
}
export function safeName(s) {return s.replace(/[<>:"/\\|?*\x00-\x1f]/g,'_').slice(0,120);}
// PDF com a captura JPEG original, sem recorte e sem serviços externos.
export function screenshotPdf(jpeg, width, height) {
  const enc=new TextEncoder(), chunks=[]; let size=0; const offsets=[0];
  const put=x=>{const b=typeof x==='string'?enc.encode(x):x; chunks.push(b);size+=b.length;};
  const object=(n,body)=>{offsets[n]=size;put(`${n} 0 obj\n${body}\nendobj\n`);};
  const pageW=842, pageH=Math.max(595,Math.ceil(pageW*height/width));
  put('%PDF-1.4\n');object(1,'<< /Type /Catalog /Pages 2 0 R >>');
  object(2,'<< /Type /Pages /Kids [3 0 R] /Count 1 >>');
  object(3,`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageW} ${pageH}] /Resources << /XObject << /Img 4 0 R >> >> /Contents 5 0 R >>`);
  offsets[4]=size;put(`4 0 obj\n<< /Type /XObject /Subtype /Image /Width ${width} /Height ${height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpeg.length} >>\nstream\n`);put(jpeg);put('\nendstream\nendobj\n');
  const h=pageW*height/width, stream=`q ${pageW} 0 0 ${h} 0 ${pageH-h} cm /Img Do Q\n`;
  object(5,`<< /Length ${enc.encode(stream).length} >>\nstream\n${stream}endstream`);
  const start=size;put('xref\n0 6\n0000000000 65535 f \n');for(let n=1;n<=5;n++)put(`${String(offsets[n]).padStart(10,'0')} 00000 n \n`);
  put(`trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${start}\n%%EOF\n`);
  return new Blob(chunks,{type:'application/pdf'});
}
