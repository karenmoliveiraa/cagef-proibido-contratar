async function fillMemo245(memo,process){
 const editors=Object.values(window.CKEDITOR?.instances||{}).filter(e=>e.status==='ready');if(!editors.length)return {waiting:true};
 if(!document.body.textContent.replace(/\D/g,'').includes(process.replace(/\D/g,'')))return {error:'Processo não confirmado no editor.'};
 const esc=s=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const snapshots=editors.map(editor=>({editor,html:editor.getData()}));const text=html=>new DOMParser().parseFromString(html,'text/html').body.textContent;
 const recipient=snapshots.filter(s=>s.html.includes('@nome_destinatario@')&&s.html.includes('@cargo_destinatario@'));
 const body=snapshots.filter(s=>s.html.includes('@vocativo_destinatario@')&&/\[\s*Inserir Texto\s*\]/i.test(text(s.html)));
 const ref=snapshots.filter(s=>/Refer[eê]ncia\s*:/i.test(text(s.html)));
 if(recipient.length!==1||body.length!==1||ref.length!==1||new Set([recipient[0].editor,body[0].editor,ref[0].editor]).size!==3)return {error:'Modelo do editor diferente do esperado ou já preenchido. Nenhum texto foi substituído. Confira o rascunho.'};
 const parts=memo.split('\n\n');const reference=parts.find(p=>p.startsWith('Referência:'));const salutation=parts.find(p=>p.startsWith('Prezada'));const start=parts.indexOf(salutation),paras=parts.slice(start+1);if(!reference||!salutation||start<0)return {error:'Minuta sem referência ou vocativo.'};
 const bdoc=new DOMParser().parseFromString(body[0].html,'text/html');const placeholder=[...bdoc.querySelectorAll('p')].filter(p=>/^\[\s*Inserir Texto\s*\]$/i.test(p.textContent.trim()));if(placeholder.length!==1)return {error:'Não há um único espaço vazio para o corpo.'};
 const fragment=bdoc.createDocumentFragment();for(const para of paras){const p=bdoc.createElement('p');p.innerHTML=esc(para).replace(/\n/g,'<br>');fragment.append(p);}placeholder[0].replaceWith(fragment);
 const replacements=[[recipient[0].editor,recipient[0].html.replaceAll('@nome_destinatario@','Ana Luiza Camargo Hirle').replaceAll('@cargo_destinatario@','Subsecretária de Compras Públicas')],[ref[0].editor,`<p>${esc(reference)}</p>`],[body[0].editor,bdoc.body.innerHTML.replaceAll('@vocativo_destinatario@',esc(salutation))]];
 await Promise.all(replacements.map(([e,html])=>new Promise(resolve=>e.setData(html,{callback:resolve}))));for(const[e]of replacements)e.updateElement();return {filled:true};
}
