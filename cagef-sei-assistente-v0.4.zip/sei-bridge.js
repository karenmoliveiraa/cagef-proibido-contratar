(() => {
 if(window.top!==window)return;
 const walk=(cb,doc=document,seen=new Set())=>{if(!doc?.documentElement||seen.has(doc))return;seen.add(doc);cb(doc);for(const f of doc.querySelectorAll('iframe,frame')){try{if(f.contentDocument)walk(cb,f.contentDocument,seen);}catch{}}};
 const process=()=>document.title.match(/\d{4}\.\d{2}\.\d{7}\/\d{4}-\d{2}/)?.[0]||'';
 async function catalogue(expected){
  if(process()!==expected)throw Error('O processo da página mudou. Reabra o painel.');
  let tree;walk(doc=>{if(doc.querySelector('#topmenu'))tree=doc;});if(!tree)throw Error('Árvore do SEI não carregada.');
  const open=[...tree.querySelectorAll('a')].find(a=>a.querySelector('img[alt="Abrir todas as Pastas"]'));
  if(open){open.click();await new Promise(resolve=>setTimeout(resolve,500));}
  let stable=0,last=-1,docs=[];
  for(let n=0;n<60;n++){
   if(process()!==expected)throw Error('O processo mudou durante a leitura.');
   walk(doc=>{if(doc.querySelector('#topmenu'))tree=doc;});
   const found=new Map();for(const a of tree.querySelectorAll('a[href]')){let u;try{u=new URL(a.getAttribute('href'),tree.baseURI);}catch{continue;}
    if(/^anchor\d+$/.test(a.id)&&/Documento Cancelado/i.test(a.title)){const id=a.id.replace('anchor','');found.set(id,{id,url:'',label:a.textContent.trim(),sei:a.textContent.match(/\b\d{7,12}\b/)?.[0]||'',status:'cancelado'});continue;}
    const id=u.searchParams.get('id_documento');if(!id||u.searchParams.get('acao')!=='arvore_visualizar')continue;
    const label=a.textContent.trim();if(!label||!/^anchor\d+$/.test(a.id))continue;
    found.set(id,{id,url:u.href,label,sei:label.match(/\((\d{7,12})\)/)?.[1]||label.match(/\b\d{7,12}\b/)?.[0]||'',status:/cancelad/i.test(a.title)?'cancelado':'pendente'});
   }
   docs=[...found.values()];const loading=/Aguarde\.\.\./i.test(tree.body.innerText),closed=[...tree.querySelectorAll('img[alt^="Abrir Pasta"]')].length;
   if(docs.length===last&&!loading&&!closed)stable++;else stable=0;last=docs.length;if(stable>=3)break;
   if(n===59)throw Error('Nem todas as pastas terminaram de abrir. Aguarde e repita.');await new Promise(resolve=>setTimeout(resolve,300));
  }
  if(!docs.length)throw Error('Nenhum documento foi encontrado na árvore do processo.');
  let inclusion='';walk(doc=>{for(const a of doc.querySelectorAll('a[href]'))if(a.querySelector('img[alt="Incluir Documento"]')){const u=new URL(a.getAttribute('href'),doc.baseURI);if(u.searchParams.get('id_procedimento')===new URL(location.href).searchParams.get('id_procedimento'))inclusion=u.href;}});
  return {documents:docs,inclusion,procedureId:new URL(location.href).searchParams.get('id_procedimento')};
 }
 chrome.runtime.onMessage.addListener((m,s,reply)=>{
  if(m?.type==='CAGEF_CATALOGUE'){catalogue(m.process).then(reply,e=>reply({error:e.message}));return true;}
  if(m?.type==='CAGEF_NAVIGATE_INCLUDE'){
   if(process()!==m.process)return reply({error:'O processo mudou. A inclusão foi bloqueada.'});
   let link;walk(doc=>{for(const a of doc.querySelectorAll('a[href]'))if(a.querySelector('img[alt="Incluir Documento"]')){const u=new URL(a.getAttribute('href'),doc.baseURI);if(u.origin===location.origin&&u.searchParams.get('id_procedimento')===new URL(location.href).searchParams.get('id_procedimento')&&u.searchParams.get('acao')==='documento_escolher_tipo')link=a;}});
   if(!link)return reply({error:'Selecione o nó principal do processo para exibir Incluir Documento.'});link.click();reply({ok:true});
  }
 });
})();
