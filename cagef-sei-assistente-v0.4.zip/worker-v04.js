importScripts('db.js','memo-fill.js');
const isCagef=raw=>{try{const u=new URL(raw);return u.protocol==='https:'&&['www.cagef.mg.gov.br','cagef.mg.gov.br'].includes(u.hostname);}catch{return false;}};
const isApp=s=>s.url?.split('?')[0]===chrome.runtime.getURL('app.html');
let flowQueue=Promise.resolve();
const toBase64=bytes=>{let out='';for(let n=0;n<bytes.length;n+=32768)out+=String.fromCharCode(...bytes.subarray(n,n+32768));return btoa(out);};
async function activeContext(message,sender){
 if(!isApp(sender))throw Error('Origem não autorizada.');
 const key=`context:${message.token}`,context=(await chrome.storage.session.get(key))[key];if(!context?.process)throw Error('Reabra o painel em um processo SEI.');
 const tab=await chrome.tabs.get(context.target.id);if(!isSei(tab.url)||new URL(tab.url).searchParams.get('id_procedimento')!==new URL(context.target.url).searchParams.get('id_procedimento'))throw Error('O processo da aba mudou. Reabra o painel.');return context;
}
async function appRequest(m,s){
 const c=await activeContext(m,s),key=`flow:${c.process}`;let flow=(await chrome.storage.session.get(key))[key];
 if(m.action==='CATALOGUE'){const result=await chrome.tabs.sendMessage(c.target.id,{type:'CAGEF_CATALOGUE',process:c.process},{frameId:0});return result;}
 if(m.action==='READ_URL'){
  const u=new URL(m.url);const allow=['arvore_visualizar','arvore_processar_html','documento_visualizar','documento_consultar','documento_download','documento_download_anexo','anexo_download','arquivo_download'];
  if(!isSei(u.href)||!allow.includes(u.searchParams.get('acao')))throw Error('URL de leitura não autorizada.');
  const pid=u.searchParams.get('id_procedimento');if(pid&&pid!==new URL(c.target.url).searchParams.get('id_procedimento'))throw Error('Documento de outro processo bloqueado.');
  const r=await fetch(u.href,{credentials:'include',redirect:'error',signal:AbortSignal.timeout(60000)});if(!r.ok)throw Error(`Falha HTTP ${r.status}.`);
  if(Number(r.headers.get('content-length')||0)>24*1024*1024)throw Error('Documento maior que 24 MB. Importe o arquivo localmente para leitura.');
  const bytes=new Uint8Array(await r.arrayBuffer());if(bytes.length>24*1024*1024)throw Error('Documento maior que 24 MB. Importe localmente.');return {base64:toBase64(bytes),mime:r.headers.get('content-type')||'application/octet-stream',url:r.url};
 }
 if(m.action==='STATUS')return {flow};
 if(m.action==='CONFIRM_MEMO'){
  if(flow?.kind!=='memo'||flow.stage!=='verify'||!flow.documentId||m.documentId!==flow.documentId)throw Error('Documento de confirmação divergente.');
  flow.stage='done';flow.message=`Memorando SEI ${flow.sei}: conteúdo confirmado no documento salvo. Revise antes de assinar.`;await chrome.storage.session.set({[key]:flow});return {flow};
 }
 if(m.action==='STOP'){if(flow){flow.stage='stopped';flow.message='Automação cancelada. Confira o sistema antes de repetir.';await chrome.storage.session.set({[key]:flow});}return {flow};}
 if(m.action==='START_CAGEF'){
  if(!m.approved)throw Error('É necessária a revisão e autorização para este condenado.');
  if(flow&&!['done','stopped','failed','captured'].includes(flow.stage))throw Error('Conclua ou cancele a operação em andamento.');
  const p=m.person;if(!p?.doc||!p.nome||!p.annotation||!p.judicial||p.annotation.length>20000)throw Error('Dados da anotação incompletos.');
  const tabs=await chrome.tabs.query({url:['https://www.cagef.mg.gov.br/*','https://cagef.mg.gov.br/*']});const tab=tabs[0]||await chrome.tabs.create({url:'https://www.cagef.mg.gov.br/fornecedor-web/br/gov/prodemge/seplag/fornecedor/publico/index.zul',active:true});
  const otherKey=(await chrome.storage.session.get(`flowtab:${tab.id}`))[`flowtab:${tab.id}`],other=otherKey&&(await chrome.storage.session.get(otherKey))[otherKey];if(other&&other.expires>Date.now()&&!['done','stopped','failed','captured'].includes(other.stage))throw Error('A aba CAGEF já está executando outra operação. Conclua-a ou cancele antes.');
  flow={kind:'cagef',stage:'navigate',process:c.process,person:p,index:m.index,tabId:tab.id,expires:Date.now()+30*60*1000,message:'Aguardando sessão e navegação CAGEF.'};await chrome.storage.session.set({[key]:flow,[`flowtab:${tab.id}`]:key});await chrome.tabs.update(tab.id,{active:true});return {flow};
 }
 if(m.action==='START_SEI'){
  if(!m.approved)throw Error('Autorize a inclusão no SEI após conferir a prévia.');
  if(flow&&!['done','stopped','failed','captured'].includes(flow.stage))throw Error('Há uma operação em andamento.');
  if(!['external','memo'].includes(m.kind))throw Error('Tipo inválido.');
  if(m.kind==='external'&&!await fileGet(m.fileKey))throw Error('PDF indisponível. Gere ou importe a captura primeiro.');
  if(m.kind==='memo'&&(!m.memo||m.memo.includes('[PENDENTE]')))throw Error('Minuta incompleta.');
  const catalogue=await chrome.tabs.sendMessage(c.target.id,{type:'CAGEF_CATALOGUE',process:c.process},{frameId:0});if(catalogue.error)throw Error(catalogue.error);
  if(m.kind==='external'&&catalogue.documents.some(d=>d.status!=='cancelado'&&d.label.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().includes(m.name.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase())))throw Error('Já existe documento com esse nome na árvore. Confira antes de repetir.');
  flow={kind:m.kind,stage:'type',process:c.process,procedureId:catalogue.procedureId,index:m.index,personDoc:m.personDoc,tabId:c.target.id,fileKey:m.fileKey,name:m.name,memo:m.memo,before:catalogue.documents.map(d=>d.id),expires:Date.now()+20*60*1000,message:'Iniciando inclusão no SEI.'};
  await chrome.storage.session.set({[key]:flow,[`flowtab:${c.target.id}`]:key});
  const result=await chrome.tabs.sendMessage(c.target.id,{type:'CAGEF_NAVIGATE_INCLUDE',process:c.process},{frameId:0});if(result?.error){flow.stage='failed';flow.message=result.error;await chrome.storage.session.set({[key]:flow});throw Error(result.error);}await chrome.tabs.update(c.target.id,{active:true});return {flow};
 }
 if(m.action==='POLL_DOCUMENT'){
  if(!flow||!['submitted','saved','verify'].includes(flow.stage)||!['external','memo'].includes(flow.kind))return {flow};
  const cat=await chrome.tabs.sendMessage(c.target.id,{type:'CAGEF_CATALOGUE',process:c.process},{frameId:0});if(cat.error)return {flow};
  const fold=s=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  const candidates=cat.documents.filter(d=>!flow.before.includes(d.id)&&(flow.kind==='memo'?/^Memorando\b/i.test(d.label):fold(d.label).includes(fold(flow.name))));
  if(candidates.length===1){flow.sei=candidates[0].sei;flow.documentId=candidates[0].id;flow.documentUrl=candidates[0].url;
   if(flow.kind==='external'){flow.stage='done';flow.message=`Inclusão confirmada na árvore: ${candidates[0].label}`;}await chrome.storage.session.set({[key]:flow});}
  return {flow};
 }
 throw Error('Operação desconhecida.');
}
chrome.runtime.onMessage.addListener((m,s,reply)=>{
 if(m?.type==='CAGEF_V4'){flowQueue=flowQueue.catch(()=>{}).then(()=>appRequest(m,s)).then(reply,e=>reply({error:e.message}));return true;}
 if(m?.type!=='CAGEF_AGENT'||!s.tab||(!isSei(s.url)&&!isCagef(s.url)))return;
 flowQueue=flowQueue.catch(()=>{}).then(async()=>{
  const tabKey=`flowtab:${s.tab.id}`,key=(await chrome.storage.session.get(tabKey))[tabKey];if(!key)return {job:null};let job=(await chrome.storage.session.get(key))[key];
  if(!job||job.tabId!==s.tab.id||job.expires<Date.now()||['done','failed','stopped','captured'].includes(job.stage))return {job:null};
  if((job.kind==='cagef')!==isCagef(s.url))return {job:null};
  if(m.action==='GET')return {job};
  if(m.action==='REUSE'){
   if(job.kind!=='cagef'||job.stage!=='identity'||typeof m.annotation!=='string'||!m.annotation.includes(job.person.judicial)||m.annotation.length>20000)throw Error('Registro existente não confirmado.');
   job.person.annotation=m.annotation;job.person.origem=m.origin==='CAFIMP'?'CAFIMP':'Manual';job.existing=true;job.stage='saved';job.message='Registro existente encontrado para o mesmo processo judicial. Nenhuma anotação foi criada. Confira a consulta e clique no ícone da extensão para capturar.';
   await chrome.storage.session.set({[key]:job});return {job};
  }
  if(m.action==='CLAIM'){
   const transitions={navigate:['query','identity'],query:['queryWait','identity'],queryWait:['identity'],identity:['lookup'],lookup:['filled'],filled:['submitted'],type:['form','metadata'],form:['uploading'],uploading:['submitted'],metadata:['editor'],editor:['verify'],submitted:['saved'],saved:[]};
   if(job.stage!==m.from||!transitions[m.from]?.includes(m.to))return {claimed:false};job.stage=m.to;if(m.to==='verify')job.savedText=true;
  }else if(m.action==='FAIL'){job.stage='failed';job.message=m.message||'Automação interrompida.';}
  else if(m.action==='NOTE')job.message=String(m.message||'').slice(0,600);
  else if(m.action==='FILE'){if(job.kind!=='external')throw Error('Arquivo indisponível.');return fileGet(job.fileKey);}
  else if(m.action==='FILL_MEMO'){
   if(job.kind!=='memo'||job.stage!=='editor')return {waiting:true};
   const result=await chrome.scripting.executeScript({target:{tabId:s.tab.id,frameIds:[s.frameId]},world:'MAIN',func:fillMemo245,args:[job.memo,job.process]});return result[0]?.result;
  }else return {job:null};
  await chrome.storage.session.set({[key]:job});return {job,claimed:true};
 }).then(reply,e=>reply({error:e.message}));return true;
});
chrome.tabs.onCreated.addListener(async tab=>{
 if(!tab.openerTabId)return;const key=(await chrome.storage.session.get(`flowtab:${tab.openerTabId}`))[`flowtab:${tab.openerTabId}`];if(!key)return;const job=(await chrome.storage.session.get(key))[key];
 if(job&&job.kind==='memo'&&['metadata','editor'].includes(job.stage)&&job.expires>Date.now()){job.tabId=tab.id;await chrome.storage.session.set({[key]:job,[`flowtab:${tab.id}`]:key});}
});
// Captura exige activeTab: a autorização é obtida pelo clique no ícone, na aba CAGEF.
chrome.action.onClicked.addListener(async tab=>{
 if(!isCagef(tab.url))return;
 const key=(await chrome.storage.session.get(`flowtab:${tab.id}`))[`flowtab:${tab.id}`];if(!key)return;
 const job=(await chrome.storage.session.get(key))[key];if(!job||job.stage!=='saved')return;
 try{const verify=await chrome.tabs.sendMessage(tab.id,{type:'CAGEF_VERIFY_CAPTURE',doc:job.person.doc,annotation:job.person.annotation});if(!verify?.ok)throw Error(verify?.error||'Abra a consulta que mostra a anotação salva e completa.');
  const data=await chrome.tabs.captureVisibleTab(tab.windowId,{format:'jpeg',quality:95});await filePut(`capture:${job.process}:${job.index}`,{data,name:job.person.nome});job.stage='captured';job.message='Captura autorizada recebida. Volte ao painel SEI para revisar o PDF.';await chrome.storage.session.set({[key]:job});
 }catch(e){job.message=e.message;await chrome.storage.session.set({[key]:job});}
});
