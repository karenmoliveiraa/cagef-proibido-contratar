import {validId,digits} from './core.js';
export const clean=s=>String(s||'').replace(/\s+/g,' ').trim();
export const norm=s=>clean(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
export const unique=a=>[...new Set(a.filter(Boolean))];
export const maskDoc=(s,type)=>type==='CPF'?digits(s).replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/,'***.$2.$3-**'):s;
const rePrazo=/\b(?:pelo\s+prazo\s+de|por|prazo\s*:?\s*)\s*(\d{1,3}\s*(?:\([^)]{1,45}\))?\s*(?:anos?|meses|mês|dias?))\b/gi;
const reInicio=/(?:a\s+contar\s+(?:da\s+data\s+)?de|a\s+partir\s+de|termo\s+inicial\s*:?|in[ií]cio\s+(?:da\s+vig[eê]ncia|do\s+prazo)\s*:?)[^.;\n]{0,180}/gi;
export function extractCase(documents,processo){
 const people=new Map(),warnings=[],c={processo,tipoOrigem:'Memorando'},facts={prazos:[],inicios:[]},existing=[];
 for(const source of documents){
  if(!['ok','ocr'].includes(source.status)){if(source.status!=='cancelado')warnings.push(`${source.label}: ${source.error||source.status}`);continue;}
  const text=clean(source.text),label=source.label||'',sei=source.sei||'';
  if(/anexo.*cagef|anexo.*anota[cç][aã]o/i.test(label)||/foi realizada a anota[cç][aã]o no sistema/i.test(text))existing.push({label,sei});
  if(/retifica[cç][aã]o|revoga[cç][aã]o|suspens[aã]o/i.test(label))warnings.push(`Documento ${label}: possível alteração de determinação anterior; confira seu efeito antes de registrar.`);
  const judicial=text.match(/\b\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}\b/);if(judicial&&!c.judicial)c.judicial=judicial[0];
  const memo=text.match(/Em aten[cç][aã]o ao\s+(Memorando|Despacho|Of[ií]cio)\s+([^()\n]{1,100})\s*\((?:Documento\s+)?SEI\s*(\d{7,12})/i);
  if(memo){c.tipoOrigem=memo[1];c.memorando=clean(memo[2]);c.memoSei=memo[3];}
  if(!c.memoSei&&/^(Memorando|Despacho)\b/i.test(label)&&/solicita|provid[eê]ncias|encaminh/i.test(text)){c.tipoOrigem=label.split(' ')[0];c.memorando=label.match(/\b\d+\b/)?.[0]||'';c.memoSei=sei;}
  const of=text.match(/constante\s+n[oa]\s+(Of[ií]cio[^()]{1,150})\s*\((?:Documento\s+)?SEI\s*(\d{7,12})/i);
  if(of){c.documentoCondenacao=clean(of[1]);c.oficioSei=of[2];c.oficio=c.documentoCondenacao.replace(/^Of[ií]cio\s*/i,'');}
  if(/^Of[ií]cio\b/i.test(label)&&/proibi[cç][aã]o\s+de\s+contratar/i.test(text)&&!c.oficioSei){c.documentoCondenacao=label.replace(/\s*\(\d+\)\s*$/,'');c.oficio=c.documentoCondenacao.replace(/^Of[ií]cio\s*/i,'');c.oficioSei=sei;}
  if(!c.orgao&&/^Of[ií]cio/i.test(label)){const org=text.match(/GOVERNO DO ESTADO DE MINAS GERAIS\s+(.{5,160}?)(?:Of[ií]cio|Superintend[eê]ncia|Diretoria)/i);if(org)c.orgao=clean(org[1]);}
  const penalty=/(?:proib[ií](?:ç[aã]o|d[oa])|impedid[oa]|imp[oõ]st[oa]|condenad[oa]|homolog)/i;
  const docRegex=/\b(CPF|CNPJ)(?:\s*n[ºo°.]*|\s*sob\s*o)?\s*[:º°.-]?\s*(\d{3}[.\s]?\d{3}[.\s]?\d{3}[-\s]?\d{2}|\d{2}[.\s]?\d{3}[.\s]?\d{3}[/\s]?\d{4}[-\s]?\d{2})\b/gi;
  for(const match of text.matchAll(docRegex)){
   const type=match[1].toUpperCase(),id=digits(match[2]);if(!validId(id,type))continue;
   const start=Math.max(0,match.index-200),end=Math.min(text.length,match.index+650),quote=text.slice(start,end);
   if(!penalty.test(quote))continue;
   const before=text.slice(Math.max(0,match.index-180),match.index);
   let name=before.split(/[;:\n]/).at(-1).replace(/[,\s]+$/,'');
   name=name.replace(/^.*?(?:aos?\s+(?:executados?|r[eé]us\/condenados?)\s+|a\s+(?=[A-ZÀ-Ý])|(?:Sr\.?|Sra\.?)\s+)/,'');
   const tokens=name.match(/[\p{L}][\p{L}.&'-]*/gu)||[];name=tokens.slice(-Math.min(tokens.length,12)).join(' ');
   name=name.replace(/^.*\b(?:rela[cç][aã]o|inclus[aã]o|imposta|executado|condenado|r[eé]u)\s+(?:ao?\s+|de\s+)?/i,'').trim();
   const fact={sei,label,quote};let person=people.get(id);if(!person){person={nome:name,tipo:type,doc:id,sancao:'',prazo:'',inicio:'',fundamento:'',origem:'Manual',anexoSei:'',evidence:[],prazoOptions:[],inicioOptions:[]};people.set(id,person);}person.evidence.push(fact);
   const scopes=[...quote.matchAll(/proibi[cç][aã]o\s+de\s+contratar[\s\S]{5,450}?(?=,?\s*pelo\s+prazo|\.\s|$)/gi)];if(scopes.length&&!person.sancao)person.sancao=clean(scopes[0][0]);
   for(const m of quote.matchAll(rePrazo))person.prazoOptions.push({value:clean(m[1]),sei,quote});
   for(const m of quote.matchAll(reInicio))person.inicioOptions.push({value:clean(m[0]),sei,quote});
  }
  for(const m of text.matchAll(rePrazo))facts.prazos.push({value:clean(m[1]),sei,label});
  for(const m of text.matchAll(reInicio))facts.inicios.push({value:clean(m[0]),sei,label});
 }
 for(const p of people.values()){
  const ps=unique(p.prazoOptions.map(f=>f.value)),is=unique(p.inicioOptions.map(f=>f.value));
  if(ps.length===1)p.prazo=ps[0];else if(ps.length>1)warnings.push(`Prazos divergentes próximos ao documento de ${p.nome}; escolha o aplicável.`);
  if(is.length===1){p.inicio=is[0];p.fundamento=`SEI ${p.inicioOptions[0].sei}: ${is[0]}`;}else warnings.push(`Termo inicial ${is.length?'divergente':'não individualizado'} para ${p.nome}. Revise as fontes.`);
 }
 if(!people.size)warnings.push('Nenhuma identidade completa com sanção próxima foi identificada. Complete os campos a partir das fontes.');
 if(existing.length)warnings.push('Há indícios de providência/anotação anterior. Confira os documentos existentes antes de novo registro.');
 return {c,persons:[...people.values()],facts,warnings,existing};
}
export function ensureReviewed(c,persons,reviewed){
 if(!reviewed)throw Error('Confirme a revisão humana dos dados e das fontes.');
 for(const key of ['processo','tipoOrigem','memorando','memoSei','documentoCondenacao','oficioSei','orgao','judicial'])if(!clean(c[key]))throw Error(`Complete o campo ${key}.`);
 if(!persons.length)throw Error('Adicione pelo menos um condenado confirmado.');
 const used=new Set();for(const p of persons){for(const k of ['nome','doc','sancao','prazo','inicio','fundamento'])if(!clean(p[k]))throw Error(`Complete ${k} de ${p.nome||'cada condenado'}.`);if(!validId(p.doc,p.tipo))throw Error(`CPF/CNPJ inválido: ${p.nome}`);if(used.has(digits(p.doc)))throw Error('Há CPF/CNPJ duplicado.');used.add(digits(p.doc));}
}
export function memo245(c,persons){
 const names=persons.map(p=>`${p.nome}, ${p.tipo}${p.tipo==='CPF'?' nº':''} ${c.mask!==false?maskDoc(p.doc,p.tipo):p.doc}`).join('; ');
 const refs=persons.map(p=>p.anexoSei||'[PENDENTE]'),singular=persons.length===1;
 const origins=unique(persons.map(p=>p.origem));
 const how=origins.length===1&&origins[0]==='CAFIMP'?'a partir de recuperação de informações por meio de integração com o CAFIMP':origins.length===1?'por meio de registro manual no CAGEF':'por registro manual e/ou recuperação por integração com o CAFIMP, conforme os anexos';
 return `Para: Ana Luiza Camargo Hirle\nSubsecretária de Compras Públicas\n\nReferência: [Caso responda este documento, indicar expressamente o Processo nº ${c.processo}].\n\nPrezada Subsecretária,\n\nEm atenção ao ${c.tipoOrigem} ${c.memorando} (Documento SEI ${c.memoSei}), que solicita providências para atendimento à sentença judicial de proibição de contratar com o Poder Público, constante no ${c.documentoCondenacao} (Documento SEI ${c.oficioSei}), presto os seguintes esclarecimentos.\n\nAs informações de fornecedores impedidos são registradas no Cadastro Geral de Fornecedores - CAGEF por meio de anotação no cadastro do respectivo fornecedor a partir das notícias recebidas acerca do impedimento, ou a partir de recuperação de informações por meio de integração com o Cadastro de Fornecedores Impedidos de Licitar e Contratar com a Administração Pública Estadual – CAFIMP, gerido pela Controladoria-Geral do Estado, na hipótese da inscrição no CAFIMP já ter sido efetuada.\n\nInformo, ainda, que foi realizada a anotação no sistema do Cagef, em relação ${singular?'ao réu/condenado':'aos réus/condenados'} ${names}, ${how}, conforme ${singular?'anexo (Documento SEI':'anexos (Documentos SEI'} ${refs.join(' e ')}).\n\nAtenciosamente,\n\nSamira Marx Pinheiro\nDiretora Central de Cadastros`;
}
export const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
