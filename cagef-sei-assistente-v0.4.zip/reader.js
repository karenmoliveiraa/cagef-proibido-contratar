import * as pdfjs from './vendor/pdf/build/pdf.mjs';
pdfjs.GlobalWorkerOptions.workerSrc=chrome.runtime.getURL('vendor/pdf/build/pdf.worker.mjs');
let ocrWorker;
async function ocr(canvas,progress){
 if(!ocrWorker)ocrWorker=await Tesseract.createWorker('por',1,{workerPath:chrome.runtime.getURL('vendor/ocr/dist/worker.min.js'),corePath:chrome.runtime.getURL('vendor/ocr/core'),langPath:chrome.runtime.getURL('vendor/ocr/lang/4.0.0_best_int'),workerBlobURL:false,gzip:true,cacheMethod:'none',logger:m=>progress?.(`OCR: ${m.status} ${Math.round((m.progress||0)*100)}%`)});
 const {data}=await ocrWorker.recognize(canvas);return {text:data.text,confidence:data.confidence};
}
export async function readPdf(bytes,progress,signal){
 const pdf=await pdfjs.getDocument({data:bytes,isEvalSupported:false,useSystemFonts:true,cMapUrl:chrome.runtime.getURL('vendor/pdf/cmaps/'),cMapPacked:true,standardFontDataUrl:chrome.runtime.getURL('vendor/pdf/standard_fonts/'),wasmUrl:chrome.runtime.getURL('vendor/pdf/wasm/')}).promise;
 const pages=[];let didOcr=false;
 try{for(let i=1;i<=pdf.numPages;i++){
  if(signal?.aborted)throw Error('Leitura cancelada.');progress?.(`Página ${i}/${pdf.numPages}`);const page=await pdf.getPage(i),content=await page.getTextContent();
  let text=content.items.map(x=>x.str+(x.hasEOL?'\n':' ')).join(''),confidence=null;
  if(text.replace(/\s/g,'').length<50){const view=page.getViewport({scale:Math.min(2,2400/page.getViewport({scale:1}).width)}),canvas=document.createElement('canvas');canvas.width=Math.ceil(view.width);canvas.height=Math.ceil(view.height);await page.render({canvasContext:canvas.getContext('2d'),viewport:view}).promise;const result=await ocr(canvas,progress);text=result.text;confidence=result.confidence;didOcr=true;canvas.width=canvas.height=0;if(confidence<55)throw Error(`OCR de baixa confiança na página ${i} (${Math.round(confidence)}%). Importe uma versão legível.`);}
  if(!text.trim())throw Error(`Página ${i} sem texto legível, mesmo após OCR.`);
  pages.push({page:i,text,confidence});page.cleanup();
 }return {text:pages.map(p=>`[Página ${p.page}${p.confidence!==null?', OCR '+Math.round(p.confidence)+'%':''}]\n${p.text}`).join('\n\n'),pages,ocr:didOcr};}finally{await pdf.destroy();}
}
export async function stopOcr(){if(ocrWorker){await ocrWorker.terminate();ocrWorker=null;}}
const allowed=url=>{try{const u=new URL(url);return u.protocol==='https:'&&['sei.mg.gov.br','www.sei.mg.gov.br'].includes(u.hostname)&&u.pathname.startsWith('/sei/');}catch{return false;}};
export async function readSeiDocument(source,request,progress,signal){
 const seen=new Set();
 async function visit(url,depth=0){
  if(!allowed(url)||seen.has(url)||depth>8)return null;seen.add(url);
  if(signal?.aborted)throw Error('Leitura cancelada.');
  const reply=await request('READ_URL',{url});if(reply.error)throw Error(reply.error);
  const bytes=Uint8Array.from(atob(reply.base64),c=>c.charCodeAt(0));
  const head=new TextDecoder().decode(bytes.slice(0,10));
  if(head.startsWith('%PDF-'))return readPdf(bytes,progress,signal);
  if(reply.mime.startsWith('image/')){const bitmap=await createImageBitmap(new Blob([bytes],{type:reply.mime}));const canvas=document.createElement('canvas');canvas.width=bitmap.width;canvas.height=bitmap.height;canvas.getContext('2d').drawImage(bitmap,0,0);bitmap.close();const result=await ocr(canvas,progress);canvas.width=canvas.height=0;if(!result.text.trim()||result.confidence<55)throw Error('Imagem sem texto legível ou OCR de baixa confiança.');return {...result,ocr:true};}
  if(!/html|text\//i.test(reply.mime))throw Error(`Formato não suportado para leitura: ${reply.mime}.`);
  const encoding=(/charset=([^;\s]+)/i.exec(reply.mime)?.[1]||'utf-8').replace(/["']/g,'');const html=new TextDecoder(encoding).decode(bytes);
  const doc=new DOMParser().parseFromString(html,'text/html');if(doc.querySelector('#pwdSenha,#txtUsuario'))throw Error('Sessão SEI expirada. Faça login e repita a leitura.');
  const children=[];for(const el of doc.querySelectorAll('iframe[src],frame[src],embed[src],object[data],a[href]')){
   let raw=el.getAttribute('src')||el.getAttribute('data')||el.getAttribute('href');if(!raw||/^javascript:/i.test(raw))continue;
   const next=new URL(raw,reply.url||url);const acao=next.searchParams.get('acao')||'';
   if(el.matches('a')&&!/^(?:documento_visualizar|documento_download|documento_download_anexo|anexo_download|arquivo_download|documento_consultar)$/.test(acao)&&!next.pathname.endsWith('.pdf'))continue;
   if(next.searchParams.get('id_documento')&&next.searchParams.get('id_documento')!==source.id)continue;
   if(allowed(next.href))children.push(next.href);
  }
  for(const child of [...new Set(children)]){const result=await visit(child,depth+1);if(result?.text?.trim())return result;}
  for(const el of doc.querySelectorAll('script,style,nav,header,footer,#infraMenu,#divInfraBarraSistema,#divInfraSidebarMenu'))el.remove();
  const text=[...doc.querySelectorAll('p')].map(p=>p.textContent).join('\n').trim()||doc.body.textContent.trim();
  if(text.length<100||/SEI\s*-\s*Visualizar Árvore/i.test(doc.title)&&!doc.querySelector('p'))throw Error('Visualizador sem conteúdo legível. Abra o documento no SEI e tente novamente.');
  return {text,ocr:false};
 }
 const result=await visit(source.url);if(!result)throw Error('Documento não pôde ser resolvido.');return result;
}
