(() => {
 if(window.top!==window)return;
 const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim().toLowerCase(),digits=s=>String(s||'').replace(/\D/g,'');
 const visible=e=>e&&e.getClientRects().length&&!e.disabled;
 const send=(action,extra={})=>chrome.runtime.sendMessage({type:'CAGEF_AGENT',action,...extra});
 const claim=async(j,to)=>(await send('CLAIM',{from:j.stage,to})).claimed;
 const exact=(selector,label)=>{const a=[...document.querySelectorAll(selector)].filter(e=>visible(e)&&norm(e.textContent||e.value)===norm(label));return a.length===1?a[0]:null;};
 const link=label=>{const a=[...document.querySelectorAll('a')].filter(e=>visible(e)&&norm(e.textContent).includes(norm(label)));return a.length===1?a[0]:null;};
 function field(label){const rows=[...document.querySelectorAll('.form-group.row')].filter(e=>visible(e)&&norm(e.querySelector('.col-form-label')?.textContent).replace(/[ *:]/g,'')===norm(label).replace(/[ *:]/g,''));const inputs=rows.flatMap(e=>[...e.querySelectorAll('input,textarea')]).filter(visible);return inputs.length===1?inputs[0]:null;}
 function change(el,value){if(!el||el.readOnly||el.disabled)throw Error('Campo não editável ou não encontrado.');el.focus();const proto=el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;Object.getOwnPropertyDescriptor(proto,'value').set.call(el,value);el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));el.blur();}
 function personRadio(j){const label=exact('label',j.person.tipo==='CPF'?'Pessoa Física':'Pessoa Jurídica');const r=label?.control||document.getElementById(label?.htmlFor||'');if(!r)return false;if(!r.checked){r.click();return false;}return true;}
 let busy=false,notice,waitUntil=0,lastStage='';
 async function note(message){if(!notice){notice=document.createElement('div');notice.id='cagef-automation-notice';notice.style.cssText='position:fixed;right:12px;bottom:12px;z-index:2147483647;background:white;border:2px solid #176b75;padding:14px;max-width:420px;font:14px Arial;color:#183142';document.body.append(notice);}notice.textContent=message;await send('NOTE',{message});}
 async function fail(message){await send('FAIL',{message});if(notice)notice.textContent=message;}
 function navigate(to){const desired=link(to);if(desired){desired.click();return true;}const menu=document.querySelector('.menuicon.ibars');if(menu){menu.click();return false;}for(const name of ['Servidores Públicos','Gestão Anotação Fornecedores']){const a=link(name);if(a&&!a.parentElement.querySelector('ul')?.getClientRects().length){a.click();return false;}}return false;}
 async function tick(){if(busy)return;busy=true;try{
  const {job:j}=await send('GET');if(!j||j.kind!=='cagef')return;if(j.stage!==lastStage){lastStage=j.stage;waitUntil=Date.now()+45000;}
  const text=document.body.innerText;
  if(/SELECIONAR UNIDADE/i.test(text)){const cell=exact('td','CAGEF - UNIDADE CADASTRADORA SEPLAG');if(cell)cell.click();return;}
  if(exact('button','Login')){await note('Faça login no CAGEF pelo fluxo normal. A extensão não armazena senha.');return;}
  if(j.stage==='navigate'){
   if(/Consulta anotações fornecedores/i.test(text)){await claim(j,'query');return;}
   navigate('Pesquisar Anotações dos Fornecedores');
  }else if(j.stage==='query'){
   if(!personRadio(j))return;const input=field(j.person.tipo);if(!input)return;
   change(input,j.person.doc);const search=exact('button','Pesquisar');if(!search)return;
   if(await claim(j,'queryWait')){search.click();await note('Consultando anotações existentes antes de qualquer cadastro…');}
  }else if(j.stage==='queryWait'){
   const rows=[...document.querySelectorAll('tr.z-listitem')].filter(e=>visible(e)&&digits(e.textContent).includes(digits(j.person.doc)));
   if(rows.length>1)return fail('Mais de um resultado para o documento. Confira a consulta manualmente.');
   if(rows.length===1){const view=rows[0].querySelector('button');if(view){view.click();await claim(j,'identity');}return;}
   // Só ausência explícita de resultados permite seguir ao cadastro.
   const empty=[...document.querySelectorAll('.z-listbox-emptybody,.z-grid-emptybody')].some(e=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0;})&&visible(exact('button','Pesquisar'))&&Date.now()+40000>waitUntil&&!document.querySelector('.z-loading');
   if(empty){if(await claim(j,'identity')){const add=exact('button','Incluir Anotação para Fornecedor não Cadastrado');if(add)add.click();else navigate('Cadastro anotação fornecedor não cadastrado');}return;}
   if(Date.now()>waitUntil)return fail('A consulta não confirmou presença nem ausência de registros. Confira manualmente; nenhum cadastro foi feito.');
  }else if(j.stage==='identity'){
   if(/Visualizar Dados Anotação/i.test(text)){
    const rows=[...document.querySelectorAll('tr.z-listitem')].filter(e=>e.getClientRects().length&&/proibi|contratar/i.test(e.textContent));
    const existing=rows.filter(r=>r.textContent.includes(j.person.judicial));if(existing.length>1)return fail('Mais de uma anotação para o mesmo processo judicial. Confira manualmente.');
    if(existing.length===1){const cells=[...existing[0].querySelectorAll('td')],annotation=(cells[0]?.textContent||'').replace(/\.{5}/g,'').trim(),origin=/cafimp/i.test(cells[2]?.textContent||'')?'CAFIMP':'Manual';const result=await send('REUSE',{annotation,origin});if(result.error)throw Error(result.error);await note(result.job.message);return;}
    if(!rows.length&&Date.now()<waitUntil)return;
    const areas=[...document.querySelectorAll('textarea')].filter(visible);if(areas.length!==1)return fail('Campo Nova Anotação não reconhecido.');
    change(areas[0],j.person.annotation);if(await claim(j,'lookup'))await note('Anotação preparada para fornecedor existente.');return;
   }
   if(!/CADASTRO ANOTAÇÃO FORNECEDOR NÃO CADASTRADO/i.test(text))return;
   if(!personRadio(j))return;const doc=field(j.person.tipo);if(!doc)return;change(doc,j.person.doc);if(await claim(j,'lookup'))await note('Aguardando consulta automática de CPF/CNPJ no cadastro…');
  }else if(j.stage==='lookup'){
   if(Date.now()+40000<waitUntil)return; // aguarda ao menos cinco segundos para a consulta ZK
   if(/Visualizar Dados Anotação/i.test(text)){if(await claim(j,'filled'))await note('Campos prontos. Preparando gravação autorizada.');return;}
   const doc=field(j.person.tipo),name=field('Nome do Fornecedor'),annotation=field('Anotação');if(!doc||!name||!annotation)return fail('Campos de cadastro alterados.');
   if(digits(doc.value)!==digits(j.person.doc))return fail('O documento exibido diverge do condenado revisado.');
   const cafimp=[...document.querySelectorAll('.form-group.row')].find(e=>/Inscrito no CAFIMP/i.test(e.textContent))?.querySelector('input');if(norm(cafimp?.value)==='sim')return fail('Fornecedor inscrito no CAFIMP. Confira a integração existente antes de registrar manualmente.');
   if(!name.readOnly&&!name.disabled)change(name,j.person.nome);else if(!norm(name.value).includes(norm(j.person.nome)))return fail('O nome retornado diverge do revisado.');
   change(annotation,j.person.annotation);await claim(j,'filled');
  }else if(j.stage==='filled'){
   const annotations=[...document.querySelectorAll('textarea')].filter(visible);if(annotations.length!==1||norm(annotations[0].value)!==norm(j.person.annotation))return fail('Texto não permaneceu no campo. Nenhuma gravação foi acionada.');
   const save=exact('button',/Visualizar Dados Anotação/i.test(text)?'Incluir Anotação':'Salvar');if(!save)return fail('Botão de gravação não identificado de forma única.');
   if(await claim(j,'submitted')){save.click();await note('Gravação acionada uma única vez. Aguardando confirmação do CAGEF…');}
  }else if(j.stage==='submitted'){
   const toast=[...document.querySelectorAll('.z-notification,.z-messagebox,.z-window-content')].filter(e=>e.getClientRects().length).map(e=>e.textContent).join(' ');
   const stored=[...document.querySelectorAll('tr.z-listitem')].some(r=>norm(r.textContent).includes(norm(j.person.annotation)));
   if(stored||/(?:salv[oa]|incluid[oa]|cadastrad[oa]|registrad[oa]).{0,50}sucesso/.test(norm(toast))){if(await claim(j,'saved'))await note('Gravação confirmada. Abra a consulta com toda a anotação visível e clique no ícone da extensão para autorizar a captura.');}
   else if(/erro|falha|inv[aá]lid/i.test(toast)||Date.now()>waitUntil)return fail('Não foi possível confirmar o salvamento. Confira o CAGEF antes de repetir.');
  }
 }catch(e){await fail(`Operação interrompida: ${e.message}`);}finally{busy=false;}}
 chrome.runtime.onMessage.addListener((m,s,reply)=>{if(m?.type!=='CAGEF_VERIFY_CAPTURE')return;
  const hasIdentity=[...document.querySelectorAll('input')].some(e=>{const r=e.getBoundingClientRect();return digits(e.value)===digits(m.doc)&&r.width>0&&r.height>0&&r.top>=0&&r.bottom<=innerHeight;});
  const rows=[...document.querySelectorAll('tr.z-listitem')].filter(e=>e.getClientRects().length&&norm(e.textContent).includes(norm(m.annotation)));
  const inside=rows.length===1&&(()=>{const r=rows[0].getBoundingClientRect();return r.top>=0&&r.bottom<=innerHeight&&r.left>=0&&r.right<=innerWidth;})();
  reply(inside&&hasIdentity?{ok:true}:{error:'A consulta deve mostrar CPF/CNPJ e a anotação completa, sem cortes. Ajuste a página e repita o clique no ícone.'});
 });setInterval(tick,1400);tick();
})();
